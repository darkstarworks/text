#version 330

// Mantle animated text.
//
// This is Minecraft's own text fragment shader with one stage added in front of
// it: before the glyph is tinted, the incoming colour is checked for a marker
// that says "this character is animated", and if it is, the colour is computed
// here on the graphics card from the game's own clock instead.
//
// Nothing else is changed. Text that carries no marker — every other word in
// the game — takes exactly the path it always did, byte for byte, so a pack
// carrying this file cannot alter how anything else looks.
//
// WHY THIS EXISTS: a server can only animate an item's name by sending the item
// again every few frames, which fights with the player's own clicks and makes
// the hand replay its equip bob. Here the name is written once and never
// changes; only the drawing of it moves. No packets, no races, and it animates
// in hands, in tooltips, and in creative alike.
//
// THE MARKER. The server writes each character in a reserved colour:
//     red   = 254            "this is a Mantle animated glyph"
//     green = 240 + id*4     which animation (0-3)
//     blue  = pos*4          how far through the word this character sits (0-63)
// Minecraft draws the drop shadow of a piece of text by keeping the top six
// bits of each channel, so a shadow arrives with every channel divided by four
// — 254 becomes 63. Both forms are recognised, and the shadow is dimmed the way
// Minecraft would have dimmed it.
//
// Only text drawn in a screen carries the marker intact: text drawn in the
// world is multiplied by the light level before it reaches here, which would
// corrupt it. That is exactly the split we want, since item names are screen
// text.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

const float MANTLE_PI = 3.14159265359;

// How much of a channel step counts as "the same value". Channels arrive as
// eighths of a 255th, so half a step is comfortably inside the noise.
const float MANTLE_EPS = 0.6;

// Minecraft's day is 24000 ticks and GameTime is the fraction through it, so
// this turns it back into ticks — the same unit the animations are written in.
const float MANTLE_TICKS_PER_DAY = 24000.0;

// ── perceptual blending ─────────────────────────────────────────────────────
//
// Fading bright red to near-black straight down the red/green/blue channels
// walks it through a muddy brown. OKLab is built so that a straight line
// between two colours matches how a person sees the fade, so red stays red and
// simply dims. Same maths as the server-side animation, so both look alike.

vec3 mantle_srgb_to_linear(vec3 c) {
    return mix(c / 12.92, pow(max((c + 0.055) / 1.055, 0.0), vec3(2.4)), step(0.04045, c));
}

vec3 mantle_linear_to_srgb(vec3 c) {
    return mix(c * 12.92, 1.055 * pow(max(c, 0.0), vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
}

vec3 mantle_to_oklab(vec3 srgb) {
    vec3 c = mantle_srgb_to_linear(srgb);
    float l = 0.4122214708 * c.r + 0.5363325363 * c.g + 0.0514459929 * c.b;
    float m = 0.2119034982 * c.r + 0.6806995451 * c.g + 0.1073969566 * c.b;
    float s = 0.0883024619 * c.r + 0.2817188376 * c.g + 0.6299787005 * c.b;
    vec3 lms = pow(max(vec3(l, m, s), 0.0), vec3(1.0 / 3.0));
    return vec3(
        0.2104542553 * lms.x + 0.7936177850 * lms.y - 0.0040720468 * lms.z,
        1.9779984951 * lms.x - 2.4285922050 * lms.y + 0.4505937099 * lms.z,
        0.0259040371 * lms.x + 0.7827717662 * lms.y - 0.8086757660 * lms.z
    );
}

vec3 mantle_from_oklab(vec3 lab) {
    float l_ = lab.x + 0.3963377774 * lab.y + 0.2158037573 * lab.z;
    float m_ = lab.x - 0.1055613458 * lab.y - 0.0638541728 * lab.z;
    float s_ = lab.x - 0.0894841775 * lab.y - 1.2914855480 * lab.z;
    vec3 lms = vec3(l_ * l_ * l_, m_ * m_ * m_, s_ * s_ * s_);
    vec3 c = vec3(
         4.0767416621 * lms.x - 3.3077115913 * lms.y + 0.2309699292 * lms.z,
        -1.2684380046 * lms.x + 2.6097574011 * lms.y - 0.3413193965 * lms.z,
        -0.0041960863 * lms.x - 0.7034186147 * lms.y + 1.7076147010 * lms.z
    );
    return clamp(mantle_linear_to_srgb(c), 0.0, 1.0);
}

vec3 mantle_blend(vec3 from, vec3 to, float t) {
    return mantle_from_oklab(mix(mantle_to_oklab(from), mantle_to_oklab(to), clamp(t, 0.0, 1.0)));
}

// ── animation 0: a heartbeat ────────────────────────────────────────────────
//
// A hard thump, a quick softer second one, then a long dark rest — two decaying
// spikes rather than a wave, because that is what reads as a pulse rather than
// as a fading light.

float mantle_spike(float phase, float at, float decay) {
    float d = phase - at;
    if (d < 0.0) d += 1.0; // the tail of a spike wraps past the end of the cycle
    return exp(-decay * d);
}

vec3 mantle_heartbeat(float ticks) {
    float phase = fract(ticks / 20.0); // one beat a second
    float strength = clamp(max(
        mantle_spike(phase, 0.00, 14.0),
        mantle_spike(phase, 0.28, 16.0) * 0.6
    ), 0.0, 1.0);
    return mantle_blend(vec3(0.1804, 0.0196, 0.0196), vec3(1.0, 0.2314, 0.2314), strength);
}

// ── animation 1: a sculk shimmer ────────────────────────────────────────────
//
// A dull grey word with a band of blue light crossing it, then resting before
// it crosses again — the way a shrieker flares. The rest is what sells it: a
// band that runs continuously reads as a loading bar.

vec3 mantle_sculk_ramp(float t) {
    // Four colours, front edge first.
    vec3 a = vec3(0.0275, 0.7255, 0.7373);
    vec3 b = vec3(0.0314, 0.9098, 0.9412);
    vec3 c = vec3(0.0000, 0.6902, 0.6824);
    vec3 d = vec3(0.0000, 0.5804, 0.5333);
    float scaled = clamp(t, 0.0, 1.0) * 3.0;
    if (scaled < 1.0) return mantle_blend(a, b, scaled);
    if (scaled < 2.0) return mantle_blend(b, c, scaled - 1.0);
    return mantle_blend(c, d, scaled - 2.0);
}

vec3 mantle_shimmer(float ticks, float pos) {
    const float SWEEP = 0.6;  // the rest of the cycle is the pause
    const float BAND = 0.45;  // how much of the word the light covers
    vec3 base = vec3(0.2902, 0.2902, 0.2902);

    float phase = fract(ticks / 70.0);
    if (phase >= SWEEP) return base;

    // Runs from just off one edge to just off the other, so the band fully
    // enters and fully leaves instead of appearing mid-word.
    float head = -BAND + (phase / SWEEP) * (1.0 + 2.0 * BAND);
    float dist = abs(pos - head);
    if (dist >= BAND) return base;

    // Raised cosine: full strength at the centre, nothing at the edges, so the
    // highlight has no hard boundary.
    float strength = (cos((dist / BAND) * MANTLE_PI) + 1.0) * 0.5;
    vec3 ramp = mantle_sculk_ramp(((pos - head) / BAND + 1.0) * 0.5);
    return mantle_blend(base, ramp, strength);
}

// ── the marker ──────────────────────────────────────────────────────────────

/**
 * Replaces `colour` when it carries the marker; returns it untouched otherwise.
 * `alpha` is preserved either way, so fading text keeps fading.
 */
vec4 mantle_animate(vec4 colour) {
    float r = colour.r * 255.0;
    bool isMain = abs(r - 254.0) < MANTLE_EPS;
    bool isShadow = abs(r - 63.0) < MANTLE_EPS;
    if (!isMain && !isShadow) return colour;

    float g = colour.g * 255.0;
    float b = colour.b * 255.0;

    float effect;
    float pos;
    if (isMain) {
        effect = floor((g - 240.0) / 4.0 + 0.5);
        pos = floor(b / 4.0 + 0.5) / 63.0;
    } else {
        // A shadow arrives with every channel divided by four.
        effect = floor(g - 60.0 + 0.5);
        pos = floor(b + 0.5) / 63.0;
    }
    if (effect < -0.5 || effect > 3.5) return colour;

    float ticks = GameTime * MANTLE_TICKS_PER_DAY;
    vec3 animated;
    if (effect < 0.5) {
        animated = mantle_heartbeat(ticks);
    } else if (effect < 1.5) {
        animated = mantle_shimmer(ticks, clamp(pos, 0.0, 1.0));
    } else {
        return colour;
    }

    // Dim a shadow the way Minecraft would have: a quarter brightness.
    if (isShadow) animated *= 0.25;
    return vec4(animated, colour.a);
}

// ── Minecraft's own text shader, unchanged below this line ──────────────────

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    vec4 tint = mantle_animate(vertexColor);

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * tint;
#else
    vec4 color = texColor * tint * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
